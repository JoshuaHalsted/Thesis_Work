import os
import sys
import yaml
import numpy as np

print(chr(27) + "[2J")

import os
directory_path = os.getcwd()
os.chdir(directory_path)
print("My current directory is : " + directory_path)
folder_name = os.path.basename(directory_path)
print("My directory name is : " + folder_name)

STAR_RESULTS_YAML = os.path.join(directory_path,'Input_File.yml')
TOTAL_SIM_VOLUME = 0.359392
GCI_RESULTS_YAML = os.path.join(directory_path,'GCI_Results.yml')

class Simulation():
    def __init__(self, sim_dict):
        self._name = sim_dict['Name']
        self._num_cells = sim_dict['Number_Cells']
        self._phi = sim_dict['Variable_of_Interest']['Value']
        #self._char_size = (TOTAL_SIM_VOLUME/self._num_cells)**(1/3)
        self._char_size = (TOTAL_SIM_VOLUME/self._num_cells)**(1)

def CreateRatio(Sim1, Sim2):
    return Sim1._char_size/Sim2._char_size

def CompareRatios(Sim_List):
    iteration = 0
    ratio_list = []
    while True:
        if iteration < 2:
            ratio_list.append(CreateRatio(Sim_List[iteration], Sim_List[iteration+1]))
            iteration += 1
        else:
            break
    return ratio_list

def main():
    with open(STAR_RESULTS_YAML) as fh:
        Analysis_Dict = yaml.load(fh, Loader=yaml.FullLoader)
    for region in Analysis_Dict.keys():
        print("*************************************************")
        print("Performing GCI analysis on %s"%region)
        print("*************************************************")
        Sim_List = []
        Phi = []
        for item in Analysis_Dict[region]:
            if item == 'Fluid_Volume':
                Fluid_Volume = Analysis_Dict[region]['Fluid_Volume']
            else:
                Sim_Instance = Simulation(Analysis_Dict[region][item])
                Sim_List.append(Sim_Instance)
                Phi.append(Sim_Instance._phi)
        Sim_List.append(Sim_List[0])
        ratio_list = CompareRatios(Sim_List)
        Epsilon = []
        for i, _ in enumerate(Phi):
            if i < (len(Phi)-1):
                Epsilon.append(Phi[i+1]-Phi[i])
        ApparentOrder = (1/np.log(ratio_list[1]))*np.abs(np.abs(Epsilon[1]/Epsilon[0])+np.log((ratio_list[0]-1)/(ratio_list[1]-1)))
        print("Apparent order is %s"%ApparentOrder)
        phi21ext = (ratio_list[0]**ApparentOrder * Phi[0]-Phi[1])/(ratio_list[0]**ApparentOrder - 1)
        print("phi21ext is %s"%phi21ext)
        phi32ext = (ratio_list[1]**ApparentOrder * Phi[1]-Phi[2])/(ratio_list[1]**ApparentOrder - 1)
        print("phi32ext is %s"%phi32ext)
        error21_a = np.abs((Phi[0]-Phi[1])/Phi[0])
        print("error21_a is %s"%error21_a)
        error21_ext = np.abs((phi21ext-Phi[0])/phi21ext)
        print("error21_ext is %s"%error21_ext)
        error32_a = np.abs((Phi[1]-Phi[2])/Phi[1])
        print("error32_a is %s"%error32_a)
        error32_ext = np.abs((phi32ext-Phi[1])/phi32ext)
        print("error32_ext is %s"%error32_ext)
        Analysis_Dict[region]['GCI_21_Fine'] = float(1.25 * error21_a / (ratio_list[0]**ApparentOrder - 1))
        Analysis_Dict[region]['GCI_32_Fine'] = float(1.25 * error32_a / (ratio_list[1]**ApparentOrder - 1))
    with open(GCI_RESULTS_YAML, 'w') as file:
        outputs = yaml.dump(Analysis_Dict, file)

main()